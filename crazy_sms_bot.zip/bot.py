BOT_TOKEN=PUT_NEW_TOKEN_HERE
ADMIN_USERNAME=YOUR_ADMIN_USERNAME   # بدون @
ADMIN_IDS=123456789                  # آيديات المدراء مفصولة بفواصل (إن وُجدت)

# قنوات الاشتراك الإجباري (عامة - باليوزرنيم)
FORCE_CH1=@SMSFARS_1
FORCE_CH2=@SMSFARS_2

# قنوات/مجموعات خاصة (chat_id تبدأ بـ -100)
CH_ATTEMPTS=-1002627555519          # قناة محاولات الشراء (خاص)
CH_LOGIN=-10026017331               # إشعارات تسجيل الدخول (تأكّد)
CH_SUPPORT_IN=-1002555952121        # تجميع رسائل العملاء من البوت (خاص)

# قنوات عامة (للعرض فقط هنا – نستعمل يوزرنيم للاشتراك الإجباري)
PUBLIC_ACTIVATIONS=@SMSFARS_2        # قناة التفعيلات العامة
PUBLIC_OFFICIAL=@SMSFARS_1           # القناة الرسمية العامة

# مفاتيح مزودي الأرقام (أضِفها لاحقًا بأمان)
FIVESIM_API_KEY=
SMSACTIVATE_API_KEY=

# عملة الرصيد
CURRENCY=₽