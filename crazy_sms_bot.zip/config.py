python-telegram-bot==20.3
requests
aiohttp